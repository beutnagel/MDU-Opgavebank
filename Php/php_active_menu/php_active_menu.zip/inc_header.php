<?php

function checkActive($check) {
	$currentFile = $_SERVER["PHP_SELF"];
	$parts = Explode('/', $currentFile);
	$currentFile = $parts[count($parts) - 1];
	if ($check === $currentFile) {
		echo "active ";
	}
}

?>
<html>
<head>
	<title>Active menu test</title>
	<style type="text/css">.active {color: #00FFFF;}</style>
</head>
<body>
<nav>
	<li><a href="index.php" class="<?php checkActive("index.php");?>">Home</a></li>
	<li><a href="page2.php" class="<?php checkActive("page2.php");?>">Page 2</a></li>
</nav>