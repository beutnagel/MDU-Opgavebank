<!DOCTYPE html>
<?php 
include('inc_header.php');
?>
<h1>Welcome to my page!</h1>
</body>
</html>