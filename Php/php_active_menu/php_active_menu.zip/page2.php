<?php 
include('inc_header.php');
?>


<h1>This is my second page of awesomeness</h1>

</body>
</html>