<?php

include('user.class.php');
$user = new USER;
$user->logOut();

?>