<?php include('includes/functions_inc.php'); ?>
<?php 
// Set up head options
$options = array(
	"title" => "About us"
);
insertHead($options);?>


<?php include('includes/menu.php'); ?>


<h1>About our awesome company!</h1>


<?php include('includes/footer.php');?>
