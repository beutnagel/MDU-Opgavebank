<?php include('includes/functions_inc.php'); ?>
<?php 
// Set up head options
$options = array(
	"title" => "What's happening near you"
);
insertHead($options);?>


<?php include('includes/menu.php'); ?>


<h1>These things are going on right now...</h1>


<?php include('includes/footer.php');?>
