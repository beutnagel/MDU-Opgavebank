<?php include('includes/functions_inc.php'); ?>
<?php 
// Set up head options
$options = array(
	"title" => "This is my site"
);
insertHead($options);?>


<?php include('includes/menu.php'); ?>

<h1>Welcome to my wonderful website.</h1>
<?php include('includes/footer.php');?>
