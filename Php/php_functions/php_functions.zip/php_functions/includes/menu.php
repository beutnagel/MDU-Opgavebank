<nav>
	<ul>
		<li><a href="index.php" class="<?php ifActiveMenuItem('index.php');?> <?php ifActiveMenuItem('/');?>">Home</a></li>
		<li><a href="gallery.php" class="<?php ifActiveMenuItem('gallery.php');?>">Gallery</a></li>
		<li><a href="about.php" class="<?php ifActiveMenuItem('about.php');?>">About</a></li>
		<li><a href="contact.php" class="<?php ifActiveMenuItem('contact.php');?>">Contact</a></li>
		<li><a href="event.php" class="<?php ifActiveMenuItem('event.php');?>">Event</a></li>
	</ul>
</nav>