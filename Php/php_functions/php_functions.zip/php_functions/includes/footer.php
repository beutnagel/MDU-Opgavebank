
<footer>
	All rights reserved &copy; <?php echo getYear();?>

</footer>
</body>
</html>