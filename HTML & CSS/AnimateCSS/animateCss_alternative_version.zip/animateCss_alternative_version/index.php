<!DOCTYPE html>
<html>
<head>
	<title>Animate.css</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="animate.css">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
	<script type="text/javascript" src="animate.js"></script>
</head>
<body onload="initiate()">

<h1 id="title">Press to animate</h1>
<section id="box"></section>
<button id="action">Press Me</button>
</body>
</html>