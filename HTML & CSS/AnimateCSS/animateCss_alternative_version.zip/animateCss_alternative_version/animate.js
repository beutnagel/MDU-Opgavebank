console.log('This javascript file just loaded');
function initiate() {
	console.log('initiate() function called');
	click_btn = document.getElementById('action');
	click_btn.addEventListener('click',	animate);
}

function animate() {
	console.log('animate() function called');
	var box = document.getElementById('box');
	box.className = "wobble";
	animateRandom();
}
function animateRandom() {
	var list = [
		"bounce",
		"tada",
		"swing",
		"shake",
		"pulse",
		"flash",
		"rubberBand"
	]
	var random = list[Math.floor(Math.random() * list.length)];
	console.log(random);
	var box = document.getElementById('box');
	box.className = "animated "+random;
	document.getElementById('title').innerText = random;

}