<!DOCTYPE html>
<html>
<head>
	<title>Animate eksempel</title>
	<link rel="stylesheet" href="animate.css">
	<link rel="stylesheet" href="style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
	<script src="animate.js"></script>
</head>
<body>

	<section id="box">
		<p>Look at me, mom!</p>
	</section>
	<button id="action">Tryk på mig</button>
</body>
</html>