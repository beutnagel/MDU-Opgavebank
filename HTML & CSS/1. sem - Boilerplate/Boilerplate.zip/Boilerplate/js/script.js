$( document ).ready(function() {
    console.log( "ready!" );

    // Indsæt kode her

});