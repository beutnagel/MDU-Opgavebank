<!DOCTYPE html>
<html>
<head>
	<title>Look up IP</title>
</head>
<body>
	<h1>Looking up an IP address</h1>
	<h2>Checking the following ip: </h2>
	<h3>The city for this is: </h3>


<script type="text/javascript">
	var xhr = new XMLHttpRequest();
	xhr.open("POST", "http://google.com", false);
	xhr.send();
</script>
</body>
</html>