<?php

$garageNames = array(
	[
		"garageCode" => "MAGASIN",
		"garageName" => "Magasin"
	],
	[
		"garageCode" => "BRUUNS",
		"garageName" => "Bruuns"
	],
	[
		"garageCode" => "KALKVAERKSVEJ",
		"garageName" => "Kalkværksvej"
	],
	[
		"garageCode" => "Navitas",
		"garageName" => "Navitas"
	],
	[
		"garageCode" => "NewBusgadehuset",
		"garageName" => "Busgadehuset"
	],
	[
		"garageCode" => "NORREPORT",
		"garageName" => "Nørreport"
	],
	[
		"garageCode" => "SALLING",
		"garageName" => "Salling"
	],
	[
		"garageCode" => "SCANDCENTER",
		"garageName" => "Scandcenter"
	],
	[
		"garageCode" => "Urban Level 1",
		"garageName" => "Dokk1 - Section 1"
	],
	[
		"garageCode" => "Urban Level 2+3",
		"garageName" => "Dokk1 - Section 2"
	],
);
